package com.assessment;

import java.util.Scanner;

public class Assessments {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.print("Enter kelvinvalue:\t");
		float kelvinValue = s.nextFloat();
		float celsiusValue = convertKelvinToCelsius(kelvinValue);
		System.out.println("kelvin value: " + kelvinValue + " To celsiusValue: " + celsiusValue);
		System.out.println("====================================================================");
		
		System.out.print("Enter poundvalue:\t");
		float poundValue = s.nextFloat();
		float kiloGramsValue = (float) convertPoundToKilograms(poundValue);
		System.out.println("pound value: " + poundValue + " To KiloGrams value: " +kiloGramsValue );
		System.out.println("====================================================================");
		
		System.out.print("Enter Milesvalue:\t");
		float milesValue = s.nextFloat();
		float kilometers = (float) convertMilesToKilometers(milesValue);
		System.out.println("Miles value: " + milesValue + " To Kilometers value: " +kilometers );
	}

	private static float convertKelvinToCelsius(float kelvin) {

		return (float) ( kelvin- 273.15);
	}
	private static double convertPoundToKilograms(float poundValue) {

		return (double) (poundValue * 0.4536);
	}
	private static double convertMilesToKilometers(float milesValue) {

		return (double) (milesValue * 1.6);
	}
}

